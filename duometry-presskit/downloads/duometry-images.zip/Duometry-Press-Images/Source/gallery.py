#!/usr/bin/env python3
"""Build the offline asset gallery and a size/checksum manifest from the exports."""
import hashlib
import html
import json
from pathlib import Path
import struct

KIT = Path(__file__).resolve().parent.parent
TITLES = {
    "01-home": "Find it by feel",
    "02-find-the-angle": "Match the target",
    "03-reveal": "The reveal",
    "04-daily-by-eye": "Daily · By Eye",
    "05-measure": "Free Measure",
    "02-guess": "Shape your guess",
    "04-solo-results": "Your precision",
    "05-together-reveal": "Everyone’s guesses",
    "06-together-standings": "The round standings",
    "07-explore": "Explore angles",
}


def main():
    cards = []
    manifest = []
    for path in sorted((KIT / "Screenshots").glob("*.png")):
        device, rest = path.stem.split("-", 1)
        stem, appearance = rest.rsplit("-", 1)
        title = TITLES[stem]
        data = path.read_bytes()
        width, height = struct.unpack(">II", data[16:24])
        relative = path.relative_to(KIT).as_posix()
        device_label = "iPhone Duo" if device == "duo" else "iPhone 18 Pro"
        manifest.append({"file": relative, "title": title, "device": device_label,
                         "appearance": appearance, "language": "en", "width": width,
                         "height": height, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        cards.append(f'''<article class="card" data-device="{device}" data-appearance="{appearance}">
          <a class="shot" href="{relative}" target="_blank"><img src="{relative}" alt="{html.escape(title)} in {appearance} mode" width="{width}" height="{height}"></a>
          <div class="caption"><h3>{html.escape(title)}</h3><p>{device_label} · {appearance.title()}</p><a href="{relative}" download>PNG · {width} × {height} <span>↗</span></a></div>
        </article>''')
    (KIT / "manifest.json").write_text(json.dumps({"app": "Duometry", "captured": "2026-09-27",
        "source": "Current working app; native simulator screenshots with deterministic sample play. Debug chrome suppressed only in the disposable capture build.",
        "screenshots": manifest}, indent=2) + "\n")
    gallery = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Duometry — Press images</title>
<style>
:root{color-scheme:light;--ink:#21291f;--muted:#68725f;--paper:#f4f5ef;--line:#dce1d3;--accent:#dfff80}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Helvetica Neue",sans-serif;-webkit-font-smoothing:antialiased}a{color:inherit}main{max-width:1440px;margin:auto;padding:52px 54px 40px}.brand{display:flex;align-items:center;gap:12px;letter-spacing:4px;font-size:13px;font-weight:650}.brand img{width:42px;height:42px;border-radius:11px}header{display:flex;justify-content:space-between;align-items:end;margin:45px 0 38px;gap:30px}h1{font-weight:500;font-size:64px;letter-spacing:-3px;margin:0 0 15px;line-height:1}header p{color:var(--muted);font-size:17px;line-height:1.5;margin:0;max-width:640px}.pill{text-decoration:none;background:var(--accent);border-radius:32px;padding:15px 22px;font-size:14px;white-space:nowrap;font-weight:550}h2{font-size:24px;font-weight:500;letter-spacing:-.7px;margin:0}section{margin-top:42px}.section-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin:0 0 19px}.meta{font-size:12px;color:var(--muted);font-family:ui-monospace,SFMono-Regular,monospace}.artwork{display:grid;grid-template-columns:repeat(3,1fr);gap:22px}.artwork img{display:block;width:100%;height:auto;border-radius:14px;border:1px solid #28351f15}.artwork h3{font-weight:500;font-size:15px;margin:13px 0 5px}.artwork a{text-decoration:none}.artwork p{font-size:12px;color:var(--muted);margin:0}.filters{display:flex;gap:8px;align-items:center;flex-wrap:wrap}button{font:inherit;font-size:12px;border:1px solid var(--line);border-radius:25px;background:transparent;padding:9px 15px;cursor:pointer;color:var(--ink)}button[aria-pressed=true]{background:var(--ink);color:var(--paper);border-color:var(--ink)}button:focus-visible,a:focus-visible{outline:3px solid #759635;outline-offset:4px}.grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:30px 22px;align-items:start}.card[hidden]{display:none}.shot{display:block;background:#e4e8dc;border-radius:15px;overflow:hidden;border:1px solid #28351f15}.shot img{display:block;width:100%;height:auto}.caption h3{font-size:14px;font-weight:550;margin:13px 0 5px}.caption p{font-size:12px;color:var(--muted);margin:0 0 9px}.caption a{font-family:ui-monospace,SFMono-Regular,monospace;font-size:10px;text-decoration:none;display:flex;justify-content:space-between;color:var(--muted)}.caption a:hover{color:var(--ink)}footer{margin-top:50px;padding-top:24px;border-top:1px solid var(--line);font-size:12px;line-height:1.7;color:var(--muted);display:flex;justify-content:space-between;gap:30px}footer p{margin:0;max-width:680px}footer a{white-space:nowrap}@media(max-width:1000px){main{padding:32px}.grid{grid-template-columns:repeat(3,1fr)}.section-head{align-items:start;flex-direction:column}header{align-items:start;flex-direction:column}h1{font-size:52px}}@media(max-width:620px){main{padding:24px}.grid{grid-template-columns:repeat(2,1fr);gap:25px 16px}.artwork{grid-template-columns:1fr}header{margin-top:35px}h1{font-size:43px}footer{flex-direction:column}}
</style>
<main><div class="brand"><img src="Brand/app-icon.png" alt="Duometry app icon">DUOMETRY</div>
<header><div><h1>A fresh angle.</h1><p>Press images from Duometry. Full-resolution app screens and three ready-to-use feature images, in citron, charcoal, and warm white.</p></div><a class="pill" href="Duometry-Press-Images.zip" download>Download all images ↓</a></header>
<section><div class="section-head"><h2>Feature images</h2><span class="meta">2400 × 1600 · PNG</span></div><div class="artwork">
<a href="Artwork/01-a-feel-for-angles.png" target="_blank"><img src="Artwork/01-a-feel-for-angles.png" alt="Solo feature image"><h3>A feel for angles</h3><p>Target → reveal · Duo</p></a>
<a href="Artwork/02-light-and-dark.png" target="_blank"><img src="Artwork/02-light-and-dark.png" alt="Light and dark appearance comparison"><h3>Two moods. Same instinct.</h3><p>Light &amp; dark · Duo</p></a>
<a href="Artwork/03-play-together.png" target="_blank"><img src="Artwork/03-play-together.png" alt="Multiplayer feature image"><h3>Pass it. Guess it. Settle it.</h3><p>Play Together · iPhone</p></a>
</div></section>
<section><div class="section-head"><h2>App screenshots <span class="meta" id="count">17</span></h2><div class="filters" role="group" aria-label="Filter screenshots">
<button data-filter="all" aria-pressed="true">All</button><button data-filter="duo" aria-pressed="false">iPhone Duo</button><button data-filter="iphone" aria-pressed="false">iPhone</button><button data-filter="light" aria-pressed="false">Light</button><button data-filter="dark" aria-pressed="false">Dark</button></div></div>
<div class="grid">''' + "\n".join(cards) + '''</div></section>
<footer><p>Native simulator captures · English · September 2026<br>Real app views with sample play. Originals are uncropped; promotional layouts use rounded presentation frames. See the included notes for capture details.</p><div><a href="Brand/app-icon.png" download>App icon ↗</a> &nbsp;·&nbsp; <a href="README.md">Capture notes ↗</a> &nbsp;·&nbsp; <a href="manifest.json">Asset manifest ↗</a></div></footer></main>
<script>document.querySelectorAll('button[data-filter]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('button[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));let count=0;document.querySelectorAll('.card').forEach(card=>{card.hidden=!(button.dataset.filter==='all'||card.dataset.device===button.dataset.filter||card.dataset.appearance===button.dataset.filter);if(!card.hidden)count++});document.getElementById('count').textContent=count}));</script></html>'''
    (KIT / "index.html").write_text(gallery)
    print(f"Gallery includes {len(cards)} screenshots")


if __name__ == "__main__":
    main()
