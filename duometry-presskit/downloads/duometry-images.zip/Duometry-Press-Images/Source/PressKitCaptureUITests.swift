import XCTest
import UIKit

/// Run by capture.py in its disposable copy of the app, never in the normal test suite.
@MainActor
final class PressKitCaptureUITests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
    }

    private func launch(_ name: String, appearance: XCUIDevice.Appearance, slider: Bool = false) -> XCUIApplication {
        XCUIDevice.shared.appearance = appearance
        let app = XCUIApplication()
        app.launchArguments = ["--uitest-profile", "presskit-\(name)", "--uitest-reset-profile",
                               "--uitest-target", "73", "--uitest-hide-hinge-controls",
                               "--daily-date", "2026-09-26", "--uitest-reduce-motion",
                               "-AppleLocale", "en_US", "-AppleLanguages", "(en)"]
        if !slider { app.launchArguments.append("--simulate-hinge") }
        app.launch()
        if slider { tap("info.dismiss", app) }
        XCTAssertTrue(app.buttons["home.quickPlay"].waitForExistence(timeout: 10))
        return app
    }

    private func tap(_ id: String, _ app: XCUIApplication) {
        let button = app.buttons[id]
        XCTAssertTrue(button.waitForExistence(timeout: 10), id)
        for _ in 0..<4 where !button.isHittable { app.swipeUp() }
        button.tap()
    }

    private func capture(_ name: String, _ app: XCUIApplication) {
        // Allow navigation, material transitions and the home illustration to settle.
        Thread.sleep(forTimeInterval: 1.2)
        // Capture the whole display: XCTest can report a shifted app frame just
        // after a full-screen-cover transition, which crops app.screenshot().
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "presskit-\(name)"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testDuoScreens() {
        for (theme, appearance) in [("dark", XCUIDevice.Appearance.dark), ("light", .light)] {
            let app = launch("duo-\(theme)", appearance: appearance)
            capture("duo-01-home-\(theme)", app)
            tap("home.measure", app)
            XCTAssertTrue(app.staticTexts["measure.angle"].waitForExistence(timeout: 5))
            capture("duo-05-measure-\(theme)", app)
            app.terminate()
            app.launch()
            tap("daily.home.play", app)
            XCTAssertTrue(app.buttons["daily.ready"].waitForExistence(timeout: 5))
            capture("duo-04-daily-by-eye-\(theme)", app)
            tap("daily.close", app)
            tap("home.quickPlay", app)
            XCTAssertTrue(app.buttons["game.lockIn"].waitForExistence(timeout: 5))
            capture("duo-02-find-the-angle-\(theme)", app)
            tap("game.lockIn", app)
            XCTAssertTrue(app.buttons["game.completeRound"].waitForExistence(timeout: 10))
            capture("duo-03-reveal-\(theme)", app)
            app.terminate()
        }
    }

    func testPhoneScreens() {
        let app = launch("phone-dark", appearance: .dark, slider: true)
        capture("iphone-01-home-dark", app)
        tap("home.quickPlay", app)
        for round in 1...5 {
            tap("game.hideTarget", app)
            let slider = app.sliders["game.angleSlider"]
            XCTAssertTrue(slider.waitForExistence(timeout: 5))
            slider.adjust(toNormalizedSliderPosition: [0.39, 0.43, 0.40, 0.38, 0.42][round - 1])
            if round == 1 { capture("iphone-02-guess-dark", app) }
            tap("game.lockIn", app)
            XCTAssertTrue(app.buttons["game.completeRound"].waitForExistence(timeout: 10))
            if round == 1 { capture("iphone-03-reveal-dark", app) }
            tap("game.completeRound", app)
        }
        XCTAssertTrue(app.buttons["game.playAgain"].waitForExistence(timeout: 8))
        capture("iphone-04-solo-results-dark", app)
        tap("game.done", app)
        tap("home.together", app)
        for (index, name) in ["Alex", "Sam"].enumerated() {
            let field = app.textFields.element(boundBy: index)
            field.tap()
            field.typeText(name + "\n")
        }
        tap("setup.start", app)
        for player in 0..<2 {
            tap("game.acceptDevice", app)
            tap("game.hideTarget", app)
            app.sliders["game.angleSlider"].adjust(toNormalizedSliderPosition: player == 0 ? 0.39 : 0.48)
            tap("game.lockIn", app)
        }
        XCTAssertTrue(app.buttons["game.completeRound"].waitForExistence(timeout: 10))
        capture("iphone-05-together-reveal-dark", app)
        tap("game.completeRound", app)
        XCTAssertTrue(app.buttons["game.advance"].waitForExistence(timeout: 8))
        capture("iphone-06-together-standings-dark", app)
        app.terminate()

        let lightApp = launch("phone-light", appearance: .light, slider: true)
        tap("home.measure", lightApp)
        let slider = lightApp.sliders["measure.slider"]
        XCTAssertTrue(slider.waitForExistence(timeout: 5))
        slider.adjust(toNormalizedSliderPosition: 0.4)
        capture("iphone-07-explore-light", lightApp)
        lightApp.terminate()
    }
}
