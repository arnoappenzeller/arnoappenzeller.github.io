#!/usr/bin/env python3
"""Capture real app screens from a disposable copy; the working app is never edited."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
KIT = ROOT / "Design/PressKit"
ENV = dict(os.environ, DEVELOPER_DIR="/Applications/Xcode 27.1.app/Contents/Developer")


def run(*args, **kwargs):
    return subprocess.run(args, env=ENV, check=True, text=True, **kwargs)


def replace(path, old, new):
    text = path.read_text()
    assert text.count(old) == 1, f"Capture source changed: {path}"
    path.write_text(text.replace(old, new))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", required=True)
    parser.add_argument("--kind", required=True, choices=["duo", "iphone"])
    args = parser.parse_args()
    staging = Path(tempfile.mkdtemp(prefix=f"duometry-presskit-{args.kind}-"))
    print(f"Capture workspace: {staging}", flush=True)
    for directory in ["Duometry", "Duometry.xcodeproj", "DuometryTests"]:
        shutil.copytree(ROOT / directory, staging / directory, ignore=shutil.ignore_patterns("xcuserdata", ".DS_Store"))
    (staging / "DuometryUITests").mkdir()
    shutil.copy2(KIT / "Source/PressKitCaptureUITests.swift", staging / "DuometryUITests")

    # Only the disposable copy suppresses development chrome. Layout, text, game
    # scoring and rendering stay in the real production views.
    replace(staging / "Duometry/Features/Home/HomeView.swift", "#if DEBUG", "#if DEBUG && !PRESSKIT")
    replace(staging / "Duometry/Features/Shared/GameComponents.swift",
            "if isSimulated || !hasReading {", "if !hasReading {")
    replace(staging / "Duometry/Features/Game/DailyFlowView.swift",
            "} else if store.isDebug {", "} else if false {")
    replace(staging / "Duometry/App/DuometryApp.swift",
            "return MockHingeAngleProvider()", "return MockHingeAngleProvider(angle: 70)")

    devices = json.loads(run("xcrun", "simctl", "list", "devices", "-j", capture_output=True).stdout)
    device = next(d for group in devices["devices"].values() for d in group if d["udid"] == args.device)
    was_booted = device["state"] == "Booted"
    if not was_booted:
        run("xcrun", "simctl", "boot", args.device)
    run("xcrun", "simctl", "bootstatus", args.device, "-b")
    run("xcrun", "simctl", "status_bar", args.device, "override", "--time", "9:41",
        "--dataNetwork", "wifi", "--wifiMode", "active", "--wifiBars", "3",
        "--cellularMode", "active", "--cellularBars", "4",
        "--batteryState", "discharging", "--batteryLevel", "100")
    result = staging / "Capture.xcresult"
    method = "testDuoScreens" if args.kind == "duo" else "testPhoneScreens"
    try:
        with (staging / "capture.log").open("w") as log:
            run("xcodebuild", "test", "-project", str(staging / "Duometry.xcodeproj"),
                "-scheme", "Duometry", "-configuration", "Debug",
                "-destination", f"platform=iOS Simulator,id={args.device}",
                "-derivedDataPath", str(staging / "DerivedData"),
                "-resultBundlePath", str(result), "-parallel-testing-enabled", "NO",
                "-collect-test-diagnostics", "never", "-maximum-concurrent-test-simulator-destinations", "1",
                f"-only-testing:DuometryUITests/PressKitCaptureUITests/{method}",
                "SWIFT_ACTIVE_COMPILATION_CONDITIONS=DEBUG PRESSKIT", "CODE_SIGNING_ALLOWED=NO",
                stdout=log, stderr=subprocess.STDOUT)
        exports = staging / "Attachments"
        run("xcrun", "xcresulttool", "export", "attachments", "--path", str(result), "--output-path", str(exports))
        manifest = json.loads((exports / "manifest.json").read_text())
        output = KIT / "Screenshots"
        output.mkdir(exist_ok=True)
        count = 0
        for test in manifest:
            for attachment in test.get("attachments", []):
                name = attachment.get("suggestedHumanReadableName", "")
                if not name.startswith("presskit-"):
                    continue
                filename = name.removeprefix("presskit-")
                # xcresult adds a UUID suffix; our names end in the appearance.
                for appearance in ["dark", "light"]:
                    if f"-{appearance}" in filename:
                        filename = filename.split(f"-{appearance}")[0] + f"-{appearance}.png"
                        break
                shutil.copy2(exports / attachment["exportedFileName"], output / filename)
                count += 1
        assert count == (10 if args.kind == "duo" else 7), f"Unexpected screenshot count: {count}"
        print(f"Exported {count} screenshots to {output}", flush=True)
    finally:
        run("xcrun", "simctl", "status_bar", args.device, "clear")
        if not was_booted:
            run("xcrun", "simctl", "shutdown", args.device)
        print(f"Capture log and results: {staging}", flush=True)


if __name__ == "__main__":
    main()
