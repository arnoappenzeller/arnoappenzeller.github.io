#!/usr/bin/env python3
"""Package the press deliverables, leaving editable build sources in the repository."""
from pathlib import Path
import zipfile

kit = Path(__file__).resolve().parent.parent
archive = kit / "Duometry-Press-Images.zip"
files = [kit / name for name in ["index.html", "README.md", "manifest.json", "Preview.png"]]
for directory in ["Artwork", "Screenshots", "Brand"]:
    files.extend(sorted((kit / directory).glob("*.png")))
files.extend(sorted(path for path in (kit / "Source").iterdir() if path.is_file()))
assert len(list((kit / "Screenshots").glob("*.png"))) == 17
assert len(list((kit / "Artwork").glob("*.png"))) == 3
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files:
        destination = Path("Duometry-Press-Images") / path.relative_to(kit)
        if path.name == "index.html":
            # The extracted gallery should not link to a second copy of its ZIP.
            page = path.read_text().replace('href="Duometry-Press-Images.zip" download>Download all images ↓',
                                            'href="README.md">Capture notes ↗')
            bundle.writestr(str(destination), page)
        else:
            bundle.write(path, destination)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
print(f"Packaged {len(files)} files · {archive.stat().st_size / 1024 / 1024:.1f} MB · {archive}")
