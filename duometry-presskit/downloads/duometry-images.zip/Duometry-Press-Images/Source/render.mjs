// NODE_PATH is accepted for the bundled runtime; a local Playwright install also works.
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
await fs.mkdir(path.join(root, 'Artwork'), { recursive: true });
const browser = await chromium.launch({ headless: true, channel: 'chrome' });
try {
  const page = await browser.newPage({ viewport: { width: 1200, height: 800 }, deviceScaleFactor: 2 });
  for (const [scene, file] of [['feature', '01-a-feel-for-angles'], ['appearance', '02-light-and-dark'], ['together', '03-play-together']]) {
    await page.goto(pathToFileURL(path.join(root, 'Source/layouts.html')).href + '?scene=' + scene);
    await page.evaluate(async () => {
      await document.fonts.ready;
      await Promise.all([...document.images].map(image => image.decode()));
    });
    await page.screenshot({ path: path.join(root, 'Artwork', file + '.png') });
    console.log('Rendered ' + file + '.png (2400 × 1600)');
  }
  const gallery = await browser.newPage({ viewport: { width: 1440, height: 1100 }, deviceScaleFactor: 1 });
  await gallery.goto(pathToFileURL(path.join(root, 'index.html')).href);
  await gallery.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all([...document.images].map(image => image.decode()));
  });
  await gallery.screenshot({ path: path.join(root, 'Preview.png'), fullPage: true });
} finally {
  await browser.close();
}
