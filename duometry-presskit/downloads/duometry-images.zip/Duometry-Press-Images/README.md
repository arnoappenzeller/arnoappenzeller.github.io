# Duometry press images

Open `index.html` for the offline gallery, or unpack `Duometry-Press-Images.zip`.

## Included

- **17 original PNG screenshots**, English, captured from the current working app on September 27, 2026.
  - iPhone Duo: **1398 × 2034**, five screens in both light and dark appearances — Home, Solo target, Solo reveal, Daily By Eye, and Free Measure.
  - iPhone 18 Pro: **1206 × 2622**, seven screens — Home, slider guessing, reveal, Solo results, multiplayer reveal, standings, and light-mode Free Measure.
- **Three promotional PNGs at 2400 × 1600**: Solo, light/dark appearances, and Play Together.
- The current app icon, a visual gallery, and a screenshot manifest with dimensions and SHA-256 checksums.

The original screenshots are native, full-display captures. The feature images place those same screens in rounded presentation frames; these are graphic layouts, not hardware renders. Use the originals when an editor needs an unframed app screen.

## Capture details

Screens were produced with Xcode 27.1 on the iPhone Duo / iOS 27.1 and iPhone 18 Pro / iOS 27.0 simulators. Both capture tours complete through the real app UI. The status bar is set to 9:41 with full signal and battery. All scores and illustrations are computed by the app from sample gameplay. Alex and Sam are example players.

The Duo tour uses simulated hinge input, a fixed 73° Solo target, and September 26, 2026 for the By Eye daily. The initial Home/Measure reading is 70°; the game resets its input to 90° when a turn starts. The phone tour uses the production slider game. These images demonstrate the interface; they are not evidence of physical hinge accuracy.

`Source/capture.py` creates a disposable copy of the project in the system temporary directory. Only that copy hides the developer menu, simulated-input badge, and isolated-storage notice, and selects the initial sample hinge angle. No production layout, scoring, text, or app source in the working repository is changed. Existing isolated test-profile support keeps sample results separate from regular player history. Simulator status overrides are cleared and devices that were initially off are shut down afterward.

## Recreate

From the repository root, select installed simulator UUIDs with `xcrun simctl list devices available`, then run:

```sh
python3 Design/PressKit/Source/capture.py --kind duo --device YOUR_DUO_UUID
python3 Design/PressKit/Source/capture.py --kind iphone --device YOUR_IPHONE_UUID
python3 Design/PressKit/Source/gallery.py
node Design/PressKit/Source/render.mjs
python3 Design/PressKit/Source/package.py
```

Rendering requires Playwright and Google Chrome. If using the bundled Codex runtime, set `NODE_PATH` to its Node packages directory. The HTML/CSS in `Source/layouts.html` is the editable artwork source. No network access is needed to view the gallery or render the artwork.

The capture script prints the temporary build directory containing the full Xcode log and `.xcresult` bundle. The capture-only UI test lives under `Source/` and is injected into the disposable project; it does not add a slow screenshot tour to the normal app test suite.
